import "expo-router/entry";
import { LogBox } from 'react-native';

LogBox.ignoreAllLogs(); // Ignora todos los logs
