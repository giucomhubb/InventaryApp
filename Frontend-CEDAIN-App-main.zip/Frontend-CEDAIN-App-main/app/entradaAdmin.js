
import EntradaAdmin from "../src/pages/entradaAdmin/index";

const EntradaAdministrador = () => {
    return (
        <EntradaAdmin />
    );
};

export default EntradaAdministrador;
