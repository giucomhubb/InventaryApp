import SignUpPage from "../src/pages/signUp";

const signUp = () => {
    return (
        <SignUpPage />
    );
};

export default signUp;