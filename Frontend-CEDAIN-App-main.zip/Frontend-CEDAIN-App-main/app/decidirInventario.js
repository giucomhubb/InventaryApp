import ChooseStoreScreen from "../src/pages/decidirInventario";

const DecidirInventario = () => {
    return (
        <ChooseStoreScreen />
    );
};

export default DecidirInventario;