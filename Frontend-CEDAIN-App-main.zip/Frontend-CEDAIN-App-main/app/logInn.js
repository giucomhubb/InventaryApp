import LoginPage  from "../src/pages/LogIn";

const log = () => {
    return (
        <LoginPage />
    );
};

export default log;