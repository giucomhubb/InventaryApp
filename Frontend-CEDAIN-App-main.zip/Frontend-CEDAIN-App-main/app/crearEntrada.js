import SeleccionProductos from "../src/pages/crearEntrada";

const CrearEntrada = () => {
    return (
        <SeleccionProductos />
    );
};

export default CrearEntrada;