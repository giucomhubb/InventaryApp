
import ListadoEntradasAdmin from "../src/pages/listadoEntradasAdmin/index";

const ListadoEntradasAdministrador = () => {
    return (
        <ListadoEntradasAdmin />
    );
};

export default ListadoEntradasAdministrador;
