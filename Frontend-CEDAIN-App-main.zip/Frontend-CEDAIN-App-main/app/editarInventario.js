import EditProductScreen from "../src/pages/editarInventario/index";

const editProductScreen = ({object}) => {
    return (
        <EditProductScreen  object = {object}/>
    );
};

export default editProductScreen;