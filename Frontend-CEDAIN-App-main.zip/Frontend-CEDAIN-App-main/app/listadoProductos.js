import ListadoProductos from "../src/pages/listadoProductos/index";

const ListadoProductosRef = () => {
    return (
        <ListadoProductos />
    );
};

export default ListadoProductosRef;