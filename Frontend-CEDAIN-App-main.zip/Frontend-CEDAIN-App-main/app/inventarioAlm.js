import Inventario3 from "../src/pages/inventarioAlmacen";

const InventarioAlm = () => {
    return (
        <Inventario3 />
    );
};

export default InventarioAlm;