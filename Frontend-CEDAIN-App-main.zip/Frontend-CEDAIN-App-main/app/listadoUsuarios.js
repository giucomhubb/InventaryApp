import ListadoUsuarios from "../src/pages/listadoUsuarios/index";

const ListadoUsuariosRef = () => {
    return (
        <ListadoUsuarios />
    );
};

export default ListadoUsuariosRef;