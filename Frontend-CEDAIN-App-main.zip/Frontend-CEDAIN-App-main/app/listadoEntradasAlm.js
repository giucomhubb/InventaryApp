import ListadoEntradasAlm from "../src/pages/listadoEntradasAlm/index";

const ListadoEntradasAlmacenista = () => {
    return (
        <ListadoEntradasAlm />
    );
};

export default ListadoEntradasAlmacenista;
