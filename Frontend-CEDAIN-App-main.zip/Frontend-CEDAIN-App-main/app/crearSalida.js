import SeleccionProductos from "../src/pages/crearSalida";

const CrearSalida = () => {
    return (
        <SeleccionProductos />
    );
};

export default CrearSalida;