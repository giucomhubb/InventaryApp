import EditarUsuarioPage from '../src/pages/editarUsuario/index';

const editarUsuario = () => {
    return (
        <EditarUsuarioPage />
    );
};

export default editarUsuario;