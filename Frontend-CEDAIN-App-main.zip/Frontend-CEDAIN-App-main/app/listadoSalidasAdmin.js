import ListadoSalidasAdmin from "../src/pages/listadoSalidasAdmin";

const ListadoSalidasAdministrador = () => {
    return (
        <ListadoSalidasAdmin />
    );
};

export default ListadoSalidasAdministrador;
