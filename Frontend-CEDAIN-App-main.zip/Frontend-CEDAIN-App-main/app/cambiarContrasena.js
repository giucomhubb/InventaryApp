import CambiarContrasenaPage from "../src/pages/cambiarContrasena/index";

const CambiarContrasena = () => {
    return (
        <CambiarContrasenaPage />
    );
};

export default CambiarContrasena;