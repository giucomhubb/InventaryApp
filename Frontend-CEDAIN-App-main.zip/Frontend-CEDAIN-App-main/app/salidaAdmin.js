import SalidaAdmin from "../src/pages/salidaAdmin/index";

const SalidaAdministrador = () => {
    return (
        <SalidaAdmin />
    );
};

export default SalidaAdministrador;
