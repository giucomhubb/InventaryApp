import ListadoSalidasAlm from "../src/pages/listadoSalidasAlm/index";

const ListadoSalidasAlmacenista = () => {
    return (
        <ListadoSalidasAlm />
    );
};

export default ListadoSalidasAlmacenista;
