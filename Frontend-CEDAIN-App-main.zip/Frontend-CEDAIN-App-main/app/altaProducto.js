import AltaProducto from '../src/pages/altaProducto';

const AltaProductoPage = () => {
    return (
        <AltaProducto />
    );
};

export default AltaProductoPage;