import AltaUsuarioPage from '../src/pages/altaUsuario';

const altaUsuarioPage = () => {
    return (
        <AltaUsuarioPage />
    );
};

export default altaUsuarioPage;