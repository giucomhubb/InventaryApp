// COPIEN ESTE ARCHIVO EN ESTA MISMA CARPETA, PONGAN SU IP Y LLAMEN AL ARCHIVO ipApi.js

const protocol = 'http';
const port = '8080';
const ip = '10.34.27.212';

export default ip;