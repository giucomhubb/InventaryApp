const almacenesReales = [
    {
        id_almacen: 1,
        nombre: 'Central',
        ciudad: 'Chihuahua'
    },
    {
        id_almacen: 3,
        nombre: 'Central',
        ciudad: 'Creel'
    }
];

export default almacenesReales;