assets
The assets folder contains all images, css files, font files, etc. for your project.
Pretty much anything that isn’t code related will be stored in this folder.
