Components


Components folder is further broken down into subfolders.
These subfolders are really useful since they help keep your components organized into different sections
instead of just being one massive blob of components.
In our example we have a ui folder which contains all our UI components like
buttons, modals, cards, etc. We also have a form folder for form specific controls
like checkboxes, inputs, date pickers, etc.
