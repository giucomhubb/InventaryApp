import { View, Text } from 'react-native'
import React from 'react'

const PagInicio = () => {
  return (
    <View>
      <Text>Home</Text>
    </View>
  )
}

export default PagInicio;