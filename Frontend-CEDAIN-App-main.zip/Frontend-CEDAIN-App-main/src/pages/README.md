Pages

This folder should contain one folder for each page in your application.
Inside of those page specific folders should be a single root file that is your page (generally index.js)
alongside all the files that are only applicable to that page.
Also the hooks are made in this folders.
