Tests

Create different folder to every page in the app
